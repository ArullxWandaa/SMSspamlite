<div>
<h1>Simple Spam OTP</h1>
<h3>Install :</h3>
pkg install php git<br>
git clone https://github.com/ArullxWandaa/SMSspamlite
<h3>Run :</h3>
cd SMSspamlite<br>
php s-SpamOtp.php
</div>


